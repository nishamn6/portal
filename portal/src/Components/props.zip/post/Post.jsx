import React from "react";
import "./Post.css";

function Post(props) {
    console.log("props", props);
    return (
        <div className="post">
                <img className="postImg"
                    src="./Image/logo-og.png" alt="" />
                <div className="postInfo">
                    <div className="postCats">
                        <span className="postCat"> React</span>
                        <span className="postCat"> JS</span>
                    </div>
                    <span className="postTitle"> {props.title}</span>
                    <hr />
                </div>
                <p className="postDesc">
                   {props.desc}
                </p>
           
        </div>

    );
}
export default Post;
